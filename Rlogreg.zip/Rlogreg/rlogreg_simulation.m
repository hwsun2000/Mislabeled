clc
clear all;

n=500;
p=1000;
nn=100;

ax=zeros(n,p,nn);
ay=zeros(n,2,nn);
w=zeros((p+1),nn);
gamma=zeros(2,2,nn);
% addpath
addpath('utils')
% seed number for experiment replication
s = RandStream('mcg16807','Seed',121121);
RandStream.setGlobalStream(s)


for i = 1:nn
% Leave one out cross validation experiment wrapper
% process .mat

filename = strcat('x',num2str(i),'.mat');

load(filename);

filename = strcat('y',num2str(i),'.mat');

load(filename);

%ax(:,:,i) = double(x);
%ay(:,i) = double(y);

%[w(:,i) gamma(:,:,i)]  

x = double(x);

y = double(y);

x=zscore(x);

 x = [ones(size(x, 1),1)  x];


    [w(:,i) gamma(:,:,i)] = rlogreg(x, castLabel(y,-1), [0.85 0.15;0.15 0.85], 1, 1e-6);

end

save('w.mat', 'w');
save('gamma.mat', 'gamma');


