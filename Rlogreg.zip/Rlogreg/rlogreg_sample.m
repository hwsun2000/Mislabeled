% Leave one out cross validation experiment wrapper
% process .mat
load('y1.mat')
load('x1.mat')
load('fd1.mat')
x = double(x);
fd = double(fd);
y = double(y);
save('colon.mat', 'x', 'y', 'fd');
% start from a clean workspace
clear all
close all
clc
% addpath
addpath('utils')
% seed number for experiment replication
s = RandStream('mcg16807','Seed',121121);
RandStream.setGlobalStream(s)

% load data
[X Y FD Xt Yt FDt] = readData('colon', 1000, true);

% merge train/test data for leave-one-out
X    = [X; Xt];
Yz   = [Y; Yt];
FD   = [FD; FDt];
Y    = correctLabel(Yz, FD);
DPNT = size(X, 1);
DIM  = size(X, 2);
idx  = 1:DPNT;

for i = 1:DPNT
    
    % independent standardisations 
    [x xt] = standardise(X(idx ~= i,:), X(idx == i,:)); 
    x      = [ones(size(x, 1),1)  x];
    xt     = [ones(size(xt,1),1) xt];
    y      = Yz(idx ~= i);    % noisy training labels
    ytz    = Yz(idx == i);    % noisy test label
    yt     = Y(idx == i);     % corrected test label

    
    % Usage: rlogreg(X, y, gamma, est_g, tol)
    %        X : M x N design matrix, M = # of observation, N = # dimensionality
    %        y : class label in {0,1} format
    %    gamma : C x C initial label flipping probability matrix 
    %            C = # of classes, row of gamma sums to 1                 
    %    est_g : boolean parameter speficifying whether or not to estimate
    %            gamma
    %     tol  : optimality tolerence value
    
    % RLogReg-F
    [w gamma] = rlogreg(x, castLabel(y,-1), [0.9 0.1;0.2 0.8], 0, 1e-6);  
    [prbz prdz eIdxz ez(i)] = evalLR(xt, ytz, w);    % evaluate w.r.t noisy labels
    [prbc prdc eIdxc ec(i)] = evalLR(xt, yt, w);     % evaluate to true labels

end

fprintf(1, 'l-o-o error w.r.t noisy test labels = %6.3f%%\n', mean(ez));
fprintf(1, 'l-o-o error w.r.t clean test labels = %6.3f%%\n', mean(ec));

