% Author: Jakramate Bootkrajang
% Desc  : A function to read data from file and return relevants information
% CAUTION, class label starts from 1

function [X Y FD Xt Yt FDt Sus] = readData(inputFile, DPNT, FW)

inFile = load(inputFile);

% discover sample size
SSIZE  = size(inFile.x,1);

% if we don't have enough points use 10% of data for testing
if (DPNT >= SSIZE)
    DPNT = round(0.80 * SSIZE);
end

% bootstraping the data
perm   = randperm(SSIZE);
x      = inFile.x (perm,:);
y      = inFile.y (perm,:);
fd     = inFile.fd(perm,:);

% file descriptor, top points are mislabelled.
if (FW)
    [a idx] = sort(fd, 'descend');
    x       = x (idx, :);
    y       = y (idx, :);
    fd      = fd(idx, :);  
    
    % the position of suspect samples
    Sus     = perm(idx);
else
    Sus     = perm;
end

% build up training set
X   = x (1:DPNT,:);
Y   = y (1:DPNT,:);
FD  = fd(1:DPNT,:);

% the rest go to test set
Xt  = x (DPNT+1:end, :);
Yt  = y (DPNT+1:end, :);
FDt = fd(DPNT+1:end, :);


