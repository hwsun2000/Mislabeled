% Function to evaluate model of logistic regression family
% Author: Jakramate Bootkrajang
% Input : x  = Samples to be classified
%         y  = Target value
%         w  = Weight vector for Sigmoid/Softmax
%         fd = Label flipping indicator
% Return: prob  = probability of predicted class
%         pred  = predicted class
%         eIdx  = misclassification vector
%         eRate = misclassification rate


function [prob pred eIdx eRate] = evalLR(x, y, w)

if (size(x,2) ~= size(w,1))
    error('input and weight vector have different length missing bias?');
end

TPNT = size(x,1);                % total number of test samples 
CLS  = size(w,2) + 1;            % determine number of classes

if (CLS == 2)        
    postY  = sigmoid(x * w);     % calculate the sigmoid
    postY  = [1-postY postY]';  
    %postYh = gamma' * postY;    % used to predict given labels
%     tmp    = gamma(:,yz) .* postY;
%     Pn     = tmp(2,:) ./ sum(tmp,1);        
else   
    postY = softmax(x * w)';     % calculate softmax for prediction        
end

[prob pred] = max(postY); 
eIdx        = (pred' ~= y);
eRate       = sum(eIdx)/TPNT;

% pred2       = (Pn > 0.5) + 1;
% eIdx2       = (pred2' ~= y);
% eRate2      = (sum(eIdx2)/TPNT) * 100;

